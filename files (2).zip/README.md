# Tesla Bank — Supabase Integration

Premium digital banking built with Next.js 14 + Supabase.

---

## Stack

| Layer | Tech |
|---|---|
| Frontend | Next.js 14 (App Router), TypeScript, Tailwind CSS |
| Auth | Supabase Auth (email/password) |
| Database | Supabase (PostgreSQL) |
| Realtime | Supabase Realtime (websockets) |
| Hosting | Vercel (recommended) |

---

## Setup

### 1. Create a Supabase project

Go to [supabase.com](https://supabase.com) → New project.

### 2. Run the database schema

In the Supabase Dashboard → SQL Editor, run:

```
supabase/migrations/001_initial_schema.sql
```

This creates:
- `profiles` table with auto-creation trigger on signup
- `accounts` table with $10,000 initial balance
- `transactions` table with full history
- `send_money()` RPC for atomic transfers
- Row Level Security policies on all tables

### 3. Enable Realtime

In Supabase Dashboard → Database → Replication, enable `accounts` and `transactions` tables.

Or run in SQL Editor:
```sql
alter publication supabase_realtime add table public.accounts;
alter publication supabase_realtime add table public.transactions;
```

### 4. Environment variables

```bash
cp .env.local.example .env.local
```

Fill in your values from Supabase Dashboard → Project Settings → API:
- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`

### 5. Install and run

```bash
npm install
npm run dev
```

---

## Project Structure

```
tesla-bank/
├── app/
│   ├── layout.tsx              # Root layout with AuthProvider
│   ├── page.tsx                # Redirects to /login
│   ├── globals.css
│   ├── login/
│   │   └── page.tsx            # Login + Signup (Supabase Auth)
│   └── dashboard/
│       └── page.tsx            # Main dashboard (realtime)
├── components/
│   └── SendMoneyModal.tsx      # Send money via Supabase RPC
├── context/
│   └── AuthContext.tsx         # Auth state provider
├── hooks/
│   └── useAccount.ts           # Account + transactions + realtime
├── lib/supabase/
│   ├── client.ts               # Browser client
│   └── server.ts               # Server client
├── types/
│   └── database.ts             # TypeScript types for all tables
├── supabase/migrations/
│   └── 001_initial_schema.sql  # Full DB schema + RLS + triggers
└── middleware.ts               # Route protection
```

---

## Security

- **Row Level Security** is enabled on all tables
- Users can only read their own profile, account, and transactions
- The `send_money` RPC runs as `security definer` (elevated to service role) so it can write to both accounts atomically, but only via the controlled function
- Route protection via Next.js middleware — `/dashboard` requires authentication

---

## Realtime

The `useAccount` hook subscribes to two Supabase Realtime channels:

1. `UPDATE` on `accounts` where `id = <user's account id>` → updates displayed balance
2. `INSERT` on `transactions` where `account_id = <user's account id>` → prepends new transaction

When another user sends you money, your balance and transaction list update automatically without a page refresh.

---

## Atomic Transfers

The `send_money(p_sender_user_id, p_recipient_email, p_amount, p_description)` PostgreSQL function:

1. Locks both accounts with `FOR UPDATE` to prevent race conditions
2. Validates sufficient funds
3. Deducts from sender, credits recipient in a single transaction
4. Inserts transaction records for both parties
5. Returns `{ success, new_balance, recipient_name }` or `{ success: false, error }`

If anything fails, PostgreSQL rolls back the entire operation.
