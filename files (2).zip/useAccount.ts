'use client'
// hooks/useAccount.ts

import { useEffect, useState, useCallback } from 'react'
import { createClient } from '@/lib/supabase/client'
import type { Account, Transaction } from '@/types/database'

interface UseAccountReturn {
  account: Account | null
  transactions: Transaction[]
  loading: boolean
  error: string | null
  refetch: () => Promise<void>
}

export function useAccount(userId: string | undefined): UseAccountReturn {
  const [account, setAccount] = useState<Account | null>(null)
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const supabase = createClient()

  const fetchData = useCallback(async () => {
    if (!userId) return
    setLoading(true)
    setError(null)

    try {
      // Fetch account
      const { data: accountData, error: accountError } = await supabase
        .from('accounts')
        .select('*')
        .eq('user_id', userId)
        .single()

      if (accountError) throw accountError
      setAccount(accountData)

      // Fetch recent transactions
      if (accountData) {
        const { data: txData, error: txError } = await supabase
          .from('transactions')
          .select('*')
          .eq('account_id', accountData.id)
          .order('created_at', { ascending: false })
          .limit(20)

        if (txError) throw txError
        setTransactions(txData ?? [])
      }
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to load account data')
    } finally {
      setLoading(false)
    }
  }, [userId, supabase])

  // Initial fetch
  useEffect(() => {
    fetchData()
  }, [fetchData])

  // Realtime subscriptions
  useEffect(() => {
    if (!userId || !account) return

    const accountChannel = supabase
      .channel(`account:${account.id}`)
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'accounts',
          filter: `id=eq.${account.id}`,
        },
        (payload) => {
          setAccount(payload.new as Account)
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'transactions',
          filter: `account_id=eq.${account.id}`,
        },
        (payload) => {
          setTransactions((prev) => [payload.new as Transaction, ...prev].slice(0, 20))
        }
      )
      .subscribe()

    return () => {
      supabase.removeChannel(accountChannel)
    }
  }, [userId, account?.id, supabase])

  return { account, transactions, loading, error, refetch: fetchData }
}
