// types/database.ts
// Auto-sync with: npx supabase gen types typescript --project-id YOUR_PROJECT_ID > types/database.ts

export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[]

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string
          full_name: string
          email: string
          avatar_url: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id: string
          full_name: string
          email: string
          avatar_url?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          full_name?: string
          email?: string
          avatar_url?: string | null
          updated_at?: string
        }
      }
      accounts: {
        Row: {
          id: string
          user_id: string
          balance: number
          currency: string
          account_number: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          balance?: number
          currency?: string
          account_number?: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          balance?: number
          currency?: string
          updated_at?: string
        }
      }
      transactions: {
        Row: {
          id: string
          account_id: string
          type: 'credit' | 'debit' | 'transfer'
          amount: number
          description: string
          recipient_email: string | null
          recipient_name: string | null
          status: 'pending' | 'completed' | 'failed'
          metadata: Json
          created_at: string
        }
        Insert: {
          id?: string
          account_id: string
          type: 'credit' | 'debit' | 'transfer'
          amount: number
          description: string
          recipient_email?: string | null
          recipient_name?: string | null
          status?: 'pending' | 'completed' | 'failed'
          metadata?: Json
          created_at?: string
        }
        Update: {
          status?: 'pending' | 'completed' | 'failed'
          metadata?: Json
        }
      }
    }
    Functions: {
      send_money: {
        Args: {
          p_sender_user_id: string
          p_recipient_email: string
          p_amount: number
          p_description: string
        }
        Returns: {
          success: boolean
          new_balance?: number
          recipient_name?: string
          error?: string
        }
      }
    }
  }
}

// Convenience aliases
export type Profile = Database['public']['Tables']['profiles']['Row']
export type Account = Database['public']['Tables']['accounts']['Row']
export type Transaction = Database['public']['Tables']['transactions']['Row']
export type TransactionType = Transaction['type']
export type TransactionStatus = Transaction['status']

export interface SendMoneyResult {
  success: boolean
  new_balance?: number
  recipient_name?: string
  error?: string
}
