'use client'
// components/SendMoneyModal.tsx

import { useState, FormEvent, useRef, useEffect } from 'react'
import { createClient } from '@/lib/supabase/client'
import type { SendMoneyResult } from '@/types/database'

interface SendMoneyModalProps {
  isOpen: boolean
  onClose: () => void
  currentBalance: number
  userId: string
}

export function SendMoneyModal({
  isOpen,
  onClose,
  currentBalance,
  userId,
}: SendMoneyModalProps) {
  const [recipientEmail, setRecipientEmail] = useState('')
  const [amount, setAmount] = useState('')
  const [description, setDescription] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<SendMoneyResult | null>(null)
  const inputRef = useRef<HTMLInputElement>(null)
  const supabase = createClient()

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 100)
      setError(null)
      setSuccess(null)
    }
  }, [isOpen])

  if (!isOpen) return null

  const parsedAmount = parseFloat(amount)
  const isValidAmount = !isNaN(parsedAmount) && parsedAmount > 0 && parsedAmount <= currentBalance

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault()
    setError(null)

    if (!recipientEmail.trim()) return setError('Recipient email is required')
    if (!isValidAmount) {
      return setError(
        parsedAmount > currentBalance
          ? `Insufficient funds. Your balance is $${currentBalance.toLocaleString('en-US', { minimumFractionDigits: 2 })}`
          : 'Enter a valid amount greater than $0'
      )
    }

    setLoading(true)

    try {
      const { data, error: rpcError } = await supabase.rpc('send_money', {
        p_sender_user_id: userId,
        p_recipient_email: recipientEmail.trim().toLowerCase(),
        p_amount: parsedAmount,
        p_description: description.trim(),
      })

      if (rpcError) throw rpcError

      const result = data as SendMoneyResult
      if (!result.success) {
        setError(result.error ?? 'Transaction failed')
      } else {
        setSuccess(result)
      }
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Transaction failed. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  const handleClose = () => {
    setRecipientEmail('')
    setAmount('')
    setDescription('')
    setError(null)
    setSuccess(null)
    onClose()
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center px-4"
      onClick={(e) => { if (e.target === e.currentTarget) handleClose() }}
    >
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" />

      {/* Modal */}
      <div className="relative bg-zinc-950 border border-zinc-800 rounded-2xl w-full max-w-md shadow-2xl shadow-black/50 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-zinc-800">
          <div>
            <h2 className="text-white font-bold text-lg tracking-wide">Send Money</h2>
            <p className="text-zinc-500 text-xs mt-0.5">
              Balance: ${currentBalance.toLocaleString('en-US', { minimumFractionDigits: 2 })}
            </p>
          </div>
          <button
            onClick={handleClose}
            className="text-zinc-500 hover:text-white transition-colors w-8 h-8 flex items-center justify-center rounded-lg hover:bg-zinc-800"
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-5 h-5">
              <path d="M6 18L18 6M6 6l12 12"/>
            </svg>
          </button>
        </div>

        {success ? (
          /* Success state */
          <div className="px-6 py-10 text-center">
            <div className="w-16 h-16 bg-green-900/40 border border-green-700 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" className="w-8 h-8 text-green-400">
                <path d="M5 13l4 4L19 7" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>
            <h3 className="text-white text-xl font-bold mb-2">Transfer Complete</h3>
            <p className="text-zinc-400 text-sm mb-1">
              ${parsedAmount.toLocaleString('en-US', { minimumFractionDigits: 2 })} sent to{' '}
              <span className="text-white font-semibold">{success.recipient_name}</span>
            </p>
            <p className="text-zinc-500 text-xs mb-8">
              New balance:{' '}
              <span className="text-zinc-300">
                ${success.new_balance?.toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </span>
            </p>
            <button
              onClick={handleClose}
              className="bg-zinc-800 hover:bg-zinc-700 text-white px-8 py-3 rounded-xl text-sm font-semibold tracking-wide transition-colors"
            >
              Done
            </button>
          </div>
        ) : (
          /* Form */
          <form onSubmit={handleSubmit} className="px-6 py-6 space-y-5">
            <div>
              <label className="block text-xs text-zinc-400 uppercase tracking-widest mb-2">
                Recipient Email
              </label>
              <input
                ref={inputRef}
                type="email"
                value={recipientEmail}
                onChange={(e) => setRecipientEmail(e.target.value)}
                placeholder="recipient@example.com"
                required
                className="w-full bg-zinc-900 border border-zinc-700 rounded-xl px-4 py-3 text-white placeholder-zinc-600 focus:outline-none focus:border-red-600 focus:ring-1 focus:ring-red-600 transition-colors text-sm"
              />
            </div>

            <div>
              <label className="block text-xs text-zinc-400 uppercase tracking-widest mb-2">
                Amount (USD)
              </label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-400 font-semibold">$</span>
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="0.00"
                  min="0.01"
                  step="0.01"
                  max={currentBalance}
                  required
                  className="w-full bg-zinc-900 border border-zinc-700 rounded-xl pl-8 pr-4 py-3 text-white placeholder-zinc-600 focus:outline-none focus:border-red-600 focus:ring-1 focus:ring-red-600 transition-colors text-sm"
                />
              </div>
              {parsedAmount > 0 && parsedAmount > currentBalance && (
                <p className="text-red-400 text-xs mt-1.5">Exceeds available balance</p>
              )}
            </div>

            <div>
              <label className="block text-xs text-zinc-400 uppercase tracking-widest mb-2">
                Note <span className="text-zinc-600 normal-case">(optional)</span>
              </label>
              <input
                type="text"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="e.g. Dinner, Rent, etc."
                maxLength={100}
                className="w-full bg-zinc-900 border border-zinc-700 rounded-xl px-4 py-3 text-white placeholder-zinc-600 focus:outline-none focus:border-red-600 focus:ring-1 focus:ring-red-600 transition-colors text-sm"
              />
            </div>

            {error && (
              <div className="bg-red-950/50 border border-red-800 rounded-xl px-4 py-3 text-red-400 text-sm">
                {error}
              </div>
            )}

            <div className="flex gap-3 pt-1">
              <button
                type="button"
                onClick={handleClose}
                className="flex-1 bg-zinc-800 hover:bg-zinc-700 text-white py-3 rounded-xl text-sm font-semibold tracking-wide transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={loading || !isValidAmount || !recipientEmail}
                className="flex-1 bg-red-600 hover:bg-red-500 disabled:bg-red-900 disabled:cursor-not-allowed text-white py-3 rounded-xl text-sm font-bold tracking-wide transition-colors flex items-center justify-center gap-2"
              >
                {loading ? (
                  <>
                    <svg className="animate-spin w-4 h-4" viewBox="0 0 24 24" fill="none">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"/>
                    </svg>
                    Sending…
                  </>
                ) : (
                  'Send Money'
                )}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  )
}
