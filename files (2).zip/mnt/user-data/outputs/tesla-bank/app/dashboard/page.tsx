'use client'
// app/dashboard/page.tsx

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/context/AuthContext'
import { useAccount } from '@/hooks/useAccount'
import { SendMoneyModal } from '@/components/SendMoneyModal'
import type { Transaction } from '@/types/database'

function formatCurrency(amount: number) {
  return amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
}

function formatDate(dateStr: string) {
  const d = new Date(dateStr)
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
}

function TransactionRow({ tx }: { tx: Transaction }) {
  const isCredit = tx.type === 'credit'
  return (
    <div className="flex items-center gap-4 py-4 border-b border-zinc-800/50 last:border-0 group">
      {/* Icon */}
      <div
        className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${
          isCredit ? 'bg-green-900/40 text-green-400' : 'bg-red-900/40 text-red-400'
        }`}
      >
        {isCredit ? (
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-5 h-5">
            <path d="M12 19V5M5 12l7-7 7 7" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        ) : (
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-5 h-5">
            <path d="M12 5v14M19 12l-7 7-7-7" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        )}
      </div>

      {/* Details */}
      <div className="flex-1 min-w-0">
        <p className="text-white text-sm font-medium truncate">{tx.description}</p>
        <p className="text-zinc-500 text-xs mt-0.5">
          {tx.recipient_name
            ? `${isCredit ? 'From' : 'To'} ${tx.recipient_name} · `
            : ''}
          {formatDate(tx.created_at)}
        </p>
      </div>

      {/* Amount */}
      <div className="text-right flex-shrink-0">
        <p className={`font-bold text-sm ${isCredit ? 'text-green-400' : 'text-red-400'}`}>
          {isCredit ? '+' : '-'}${formatCurrency(tx.amount)}
        </p>
        <p
          className={`text-xs mt-0.5 capitalize ${
            tx.status === 'completed'
              ? 'text-zinc-600'
              : tx.status === 'pending'
              ? 'text-yellow-600'
              : 'text-red-600'
          }`}
        >
          {tx.status}
        </p>
      </div>
    </div>
  )
}

function RealtimeBadge() {
  return (
    <span className="inline-flex items-center gap-1.5 text-xs text-green-400 bg-green-950/40 border border-green-900 px-2.5 py-1 rounded-full">
      <span className="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse" />
      Live
    </span>
  )
}

export default function DashboardPage() {
  const { user, profile, signOut, loading: authLoading } = useAuth()
  const { account, transactions, loading, error } = useAccount(user?.id)
  const [sendModalOpen, setSendModalOpen] = useState(false)
  const router = useRouter()

  const handleSignOut = async () => {
    await signOut()
    router.push('/login')
  }

  if (authLoading || loading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-2 border-red-600 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-zinc-500 text-sm tracking-widest uppercase">Loading</p>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center px-4">
        <div className="text-center max-w-sm">
          <p className="text-red-400 text-sm mb-4">{error}</p>
          <button onClick={() => router.refresh()} className="text-zinc-400 text-xs underline">
            Retry
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Background grid */}
      <div
        className="fixed inset-0 opacity-[0.03] pointer-events-none"
        style={{
          backgroundImage:
            'linear-gradient(#e00 1px, transparent 1px), linear-gradient(90deg, #e00 1px, transparent 1px)',
          backgroundSize: '80px 80px',
        }}
      />

      {/* Nav */}
      <nav className="relative border-b border-zinc-900 bg-black/80 backdrop-blur-sm sticky top-0 z-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 flex items-center justify-between h-16">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 bg-red-600 rounded-full flex items-center justify-center">
              <svg viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" className="w-4 h-4">
                <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/>
              </svg>
            </div>
            <span className="text-white font-bold tracking-wider text-sm">TESLA BANK</span>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-zinc-500 text-sm hidden sm:block">
              {profile?.full_name}
            </span>
            <button
              onClick={handleSignOut}
              className="text-zinc-500 hover:text-white text-xs uppercase tracking-wider transition-colors px-3 py-1.5 rounded-lg hover:bg-zinc-900"
            >
              Sign out
            </button>
          </div>
        </div>
      </nav>

      <main className="relative max-w-4xl mx-auto px-4 sm:px-6 py-8 space-y-6">
        {/* Balance card */}
        <div className="bg-zinc-950 border border-zinc-800 rounded-2xl overflow-hidden">
          {/* Card top */}
          <div className="bg-gradient-to-br from-red-950/60 via-zinc-950 to-zinc-950 px-6 pt-8 pb-6 border-b border-zinc-800/50">
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2 mb-4">
                  <p className="text-zinc-500 text-xs uppercase tracking-widest">Available Balance</p>
                  <RealtimeBadge />
                </div>
                <p className="text-5xl font-bold text-white tracking-tight">
                  ${formatCurrency(account?.balance ?? 0)}
                </p>
                <p className="text-zinc-600 text-xs mt-2 font-mono">
                  {account?.account_number}
                </p>
              </div>
              <div className="text-right">
                <p className="text-zinc-600 text-xs uppercase tracking-widest">Currency</p>
                <p className="text-white font-semibold mt-1">{account?.currency ?? 'USD'}</p>
              </div>
            </div>
          </div>

          {/* Card actions */}
          <div className="px-6 py-4 flex gap-3">
            <button
              onClick={() => setSendModalOpen(true)}
              className="flex items-center gap-2 bg-red-600 hover:bg-red-500 text-white px-5 py-2.5 rounded-xl text-sm font-bold tracking-wide transition-colors"
            >
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-4 h-4">
                <path d="M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              Send Money
            </button>

            <button
              className="flex items-center gap-2 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 px-5 py-2.5 rounded-xl text-sm font-semibold tracking-wide transition-colors"
              disabled
              title="Coming soon"
            >
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-4 h-4">
                <path d="M12 19V5M5 12l7-7 7 7" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              Deposit
            </button>
          </div>
        </div>

        {/* Transactions */}
        <div className="bg-zinc-950 border border-zinc-800 rounded-2xl">
          <div className="flex items-center justify-between px-6 py-4 border-b border-zinc-800">
            <h2 className="text-white font-bold tracking-wide">Recent Transactions</h2>
            <div className="flex items-center gap-2">
              <RealtimeBadge />
              <span className="text-zinc-600 text-xs">{transactions.length} shown</span>
            </div>
          </div>

          {transactions.length === 0 ? (
            <div className="px-6 py-16 text-center">
              <div className="w-12 h-12 border border-zinc-800 rounded-full flex items-center justify-center mx-auto mb-3">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="w-6 h-6 text-zinc-700">
                  <path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" strokeLinecap="round"/>
                </svg>
              </div>
              <p className="text-zinc-600 text-sm">No transactions yet</p>
              <p className="text-zinc-700 text-xs mt-1">Send money to get started</p>
            </div>
          ) : (
            <div className="px-6 divide-y divide-transparent">
              {transactions.map((tx) => (
                <TransactionRow key={tx.id} tx={tx} />
              ))}
            </div>
          )}
        </div>

        {/* Account info footer */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
          {[
            { label: 'Account holder', value: profile?.full_name ?? '—' },
            { label: 'Email', value: profile?.email ?? '—' },
            {
              label: 'Member since',
              value: profile?.created_at
                ? new Date(profile.created_at).toLocaleDateString('en-US', {
                    month: 'long',
                    year: 'numeric',
                  })
                : '—',
            },
          ].map(({ label, value }) => (
            <div key={label} className="bg-zinc-950 border border-zinc-800/50 rounded-xl px-4 py-3">
              <p className="text-zinc-600 text-xs uppercase tracking-widest mb-1">{label}</p>
              <p className="text-zinc-300 text-sm font-medium truncate">{value}</p>
            </div>
          ))}
        </div>
      </main>

      {account && user && (
        <SendMoneyModal
          isOpen={sendModalOpen}
          onClose={() => setSendModalOpen(false)}
          currentBalance={account.balance}
          userId={user.id}
        />
      )}
    </div>
  )
}
