-- ============================================================
-- Tesla Bank – Initial Schema
-- ============================================================

-- ─── Extensions ──────────────────────────────────────────────
create extension if not exists "uuid-ossp";

-- ─── Profiles ────────────────────────────────────────────────
create table public.profiles (
  id          uuid primary key references auth.users(id) on delete cascade,
  full_name   text not null,
  email       text not null unique,
  avatar_url  text,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

-- ─── Accounts ────────────────────────────────────────────────
create table public.accounts (
  id          uuid primary key default uuid_generate_v4(),
  user_id     uuid not null references public.profiles(id) on delete cascade,
  balance     numeric(15, 2) not null default 0.00,
  currency    text not null default 'USD',
  account_number text not null unique default 'TBK-' || upper(substring(gen_random_uuid()::text, 1, 8)),
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  constraint balance_non_negative check (balance >= 0)
);

-- ─── Transactions ─────────────────────────────────────────────
create type transaction_type as enum ('credit', 'debit', 'transfer');
create type transaction_status as enum ('pending', 'completed', 'failed');

create table public.transactions (
  id              uuid primary key default uuid_generate_v4(),
  account_id      uuid not null references public.accounts(id) on delete cascade,
  type            transaction_type not null,
  amount          numeric(15, 2) not null check (amount > 0),
  description     text not null,
  recipient_email text,
  recipient_name  text,
  status          transaction_status not null default 'completed',
  metadata        jsonb default '{}',
  created_at      timestamptz not null default now()
);

-- ─── Indexes ──────────────────────────────────────────────────
create index idx_accounts_user_id        on public.accounts(user_id);
create index idx_transactions_account_id on public.transactions(account_id);
create index idx_transactions_created_at on public.transactions(created_at desc);

-- ─── Updated_at trigger ───────────────────────────────────────
create or replace function update_updated_at_column()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger trg_profiles_updated_at
  before update on public.profiles
  for each row execute function update_updated_at_column();

create trigger trg_accounts_updated_at
  before update on public.accounts
  for each row execute function update_updated_at_column();

-- ─── Auto-create profile + account on signup ──────────────────
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
declare
  v_account_id uuid;
begin
  -- Insert profile
  insert into public.profiles (id, full_name, email)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'full_name', split_part(new.email, '@', 1)),
    new.email
  );

  -- Create account with $10,000 welcome balance
  insert into public.accounts (user_id, balance)
  values (new.id, 10000.00)
  returning id into v_account_id;

  -- Log welcome credit transaction
  insert into public.transactions (account_id, type, amount, description, status)
  values (v_account_id, 'credit', 10000.00, 'Welcome bonus – Tesla Bank', 'completed');

  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ─── Send money RPC (atomic transfer) ────────────────────────
create or replace function public.send_money(
  p_sender_user_id  uuid,
  p_recipient_email text,
  p_amount          numeric,
  p_description     text
)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_sender_account    public.accounts%rowtype;
  v_recipient_profile public.profiles%rowtype;
  v_recipient_account public.accounts%rowtype;
  v_result            jsonb;
begin
  -- Lock & fetch sender account
  select * into v_sender_account
  from public.accounts
  where user_id = p_sender_user_id
  for update;

  if not found then
    return jsonb_build_object('success', false, 'error', 'Sender account not found');
  end if;

  if v_sender_account.balance < p_amount then
    return jsonb_build_object('success', false, 'error', 'Insufficient funds');
  end if;

  -- Fetch recipient profile
  select * into v_recipient_profile
  from public.profiles
  where email = lower(trim(p_recipient_email));

  if not found then
    return jsonb_build_object('success', false, 'error', 'Recipient not found. They must have a Tesla Bank account.');
  end if;

  if v_recipient_profile.id = p_sender_user_id then
    return jsonb_build_object('success', false, 'error', 'Cannot send money to yourself');
  end if;

  -- Lock & fetch recipient account
  select * into v_recipient_account
  from public.accounts
  where user_id = v_recipient_profile.id
  for update;

  -- Deduct from sender
  update public.accounts
  set balance = balance - p_amount
  where id = v_sender_account.id;

  -- Credit recipient
  update public.accounts
  set balance = balance + p_amount
  where id = v_recipient_account.id;

  -- Record debit transaction for sender
  insert into public.transactions (account_id, type, amount, description, recipient_email, recipient_name, status)
  values (
    v_sender_account.id,
    'debit',
    p_amount,
    coalesce(nullif(trim(p_description), ''), 'Transfer to ' || v_recipient_profile.full_name),
    v_recipient_profile.email,
    v_recipient_profile.full_name,
    'completed'
  );

  -- Record credit transaction for recipient
  insert into public.transactions (account_id, type, amount, description, recipient_email, recipient_name, status)
  values (
    v_recipient_account.id,
    'credit',
    p_amount,
    'Transfer from ' || (select full_name from public.profiles where id = p_sender_user_id),
    (select email from public.profiles where id = p_sender_user_id),
    (select full_name from public.profiles where id = p_sender_user_id),
    'completed'
  );

  return jsonb_build_object(
    'success', true,
    'new_balance', (select balance from public.accounts where id = v_sender_account.id),
    'recipient_name', v_recipient_profile.full_name
  );

exception when others then
  return jsonb_build_object('success', false, 'error', sqlerrm);
end;
$$;

-- ─── Row Level Security ───────────────────────────────────────
alter table public.profiles     enable row level security;
alter table public.accounts     enable row level security;
alter table public.transactions enable row level security;

-- Profiles: users can only read/update their own profile
create policy "profiles: owner read"
  on public.profiles for select
  using (auth.uid() = id);

create policy "profiles: owner update"
  on public.profiles for update
  using (auth.uid() = id);

-- Accounts: users can only read their own account
create policy "accounts: owner read"
  on public.accounts for select
  using (auth.uid() = user_id);

-- Transactions: users can only read transactions on their own accounts
create policy "transactions: owner read"
  on public.transactions for select
  using (
    account_id in (
      select id from public.accounts where user_id = auth.uid()
    )
  );

-- ─── Realtime ─────────────────────────────────────────────────
-- Enable realtime on accounts and transactions tables
-- Run in Supabase Dashboard → Database → Replication
-- Or uncomment if using CLI:
-- alter publication supabase_realtime add table public.accounts;
-- alter publication supabase_realtime add table public.transactions;
